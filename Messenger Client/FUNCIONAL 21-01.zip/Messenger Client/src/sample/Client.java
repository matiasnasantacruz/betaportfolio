package sample;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

public class Client {

    Socket socket;

    ArrayList<Message> sentMessages;
    ArrayList<Message> receivedMessages;

    int sentMessagesIndex = 0;

    ClientThread clientThread;

    final String ip = "127.0.0.1";
    final int port = 9000;

    public void startClient(TextArea textArea, Label status) {
        try {

            sentMessages = new ArrayList<>();
            receivedMessages = new ArrayList<>();

            socket = new Socket(ip, port);
            System.out.println("Client started successfully!");
            status.setText("ONLINE!!");

            clientThread = new ClientThread(socket,textArea);
            clientThread.start();

        } catch (Exception e) { }
    }

    public void sendMessage(String message) {
        try {

            DataOutputStream outputStream;
            outputStream = new DataOutputStream(socket.getOutputStream());

            //Calendar calendar = new Calendar.getInstance();
            sentMessages.add(new Message(message, new Date()));

            Message testMessage = sentMessages.get(sentMessagesIndex);
            sentMessagesIndex++;
            System.out.println("Message sent at: "+testMessage.dateString+". "+ testMessage.messageBody );

            outputStream.writeUTF(message);

        } catch (IOException e) { }
    }
}
