package sample;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Message {

    public String messageBody;
    Date date;
    String dateString;

    public Message(String messageBody, Date date){

        this.messageBody=messageBody;
        this.date = date;

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        dateString=dateFormat.format(date);

    }

}
