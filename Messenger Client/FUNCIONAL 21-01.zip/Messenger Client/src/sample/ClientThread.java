package sample;


import javafx.scene.control.TextArea;

import java.io.*;
import java.net.Socket;

public class ClientThread extends Thread {

    Socket socket;

    TextArea textArea;

    DataInputStream inputStream;

    ClientThread(Socket socket, TextArea textArea) {
        this.socket = socket;
        this.textArea = textArea;
    }

    public void run() {
        try {
            String receivedMessage;
            inputStream = new DataInputStream(socket.getInputStream());
            while (true) {
                receivedMessage = inputStream.readUTF();

                textArea.setText(textArea.getText()+"Client incoming message: "+receivedMessage+"\n");

                System.out.println("Received message: " + receivedMessage);
                System.out.println("Incoming server message: " + receivedMessage);
            }
        } catch (IOException e) { }
    }
}

