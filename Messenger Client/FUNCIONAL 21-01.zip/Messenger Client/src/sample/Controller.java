package sample;

import javafx.scene.control.*;

public class Controller {
    public Client client;

    public Label status;
    public TextArea textArea;
    public Button sendMessageButton;
    public Button connectButton;
    public TextField textField;

    public void startClient(){

        client = new Client();
        client.startClient(textArea,status);

    }

    public void sendMessage(){

        String message = textField.getText();
        client.sendMessage(message);

    }

}
